import numpy as np
from copy import deepcopy

def printState(state):
    # Check whether squares are empty or not and assign values accordingly
    if state[0][0] != 0:
        state00=state[0][0]
    else:
        state00=' '
    if state[0][1] != 0:
        state01=state[0][1]
    else:
        state01=' '
    if state[0][2] != 0:
        state02=state[0][2]
    else:
        state02=' '
    if state[0][3] != 0:
        state03=state[0][3]
    else:
        state03=' '
    if state[0][4] != 0:
        state04=state[0][4]
    else:
        state04=' '
    if state[0][5] != 0:
        state05=state[0][5]
    else:
        state05=' '
    if state[0][6] != 0:
        state06=state[0][6]
    else:
        state06=' '
    if state[0][7] != 0:
        state07=state[0][7]
    else:
        state07=' '
    if state[0][8] != 0:
        state08=state[0][8]
    else:
        state08=' '
        
    if state[1][0] != 0:
        state10=state[1][0]
    else:
        state10=' '
    if state[1][1] != 0:
        state11=state[1][1]
    else:
        state11=' '
    if state[1][2] != 0:
        state12=state[1][2]
    else:
        state12=' '
    if state[1][3] != 0:
        state13=state[1][3]
    else:
        state13=' '
    if state[1][4] != 0:
        state14=state[1][4]
    else:
        state14=' '
    if state[1][5] != 0:
        state15=state[1][5]
    else:
        state15=' '
    if state[1][6] != 0:
        state16=state[1][6]
    else:
        state16=' '
    if state[1][7] != 0:
        state17=state[1][7]
    else:
        state17=' '
    if state[1][8] != 0:
        state18=state[1][8]
    else:
        state18=' '
        
    if state[2][0] != 0:
        state20=state[2][0]
    else:
        state20=' '
    if state[2][1] != 0:
        state21=state[2][1]
    else:
        state21=' '
    if state[2][2] != 0:
        state22=state[2][2]
    else:
        state22=' '
    if state[2][3] != 0:
        state23=state[2][3]
    else:
        state23=' '
    if state[2][4] != 0:
        state24=state[2][4]
    else:
        state24=' '
    if state[2][5] != 0:
        state25=state[2][5]
    else:
        state25=' '
    if state[2][6] != 0:
        state26=state[2][6]
    else:
        state26=' '
    if state[2][7] != 0:
        state27=state[2][7]
    else:
        state27=' '
    if state[2][8] != 0:
        state28=state[2][8]
    else:
        state28=' '
    
    if state[3][0] != 0:
        state30=state[3][0]
    else:
        state30=' '
    if state[3][1] != 0:
        state31=state[3][1]
    else:
        state31=' '
    if state[3][2] != 0:
        state32=state[3][2]
    else:
        state32=' '
    if state[3][3] != 0:
        state33=state[3][3]
    else:
        state33=' '
    if state[3][4] != 0:
        state34=state[3][4]
    else:
        state34=' '
    if state[3][5] != 0:
        state35=state[3][5]
    else:
        state35=' '
    if state[3][6] != 0:
        state36=state[3][6]
    else:
        state36=' '
    if state[3][7] != 0:
        state37=state[3][7]
    else:
        state37=' '
    if state[3][8] != 0:
        state38=state[3][8]
    else:
        state38=' '
        
    if state[4][0] != 0:
        state40=state[4][0]
    else:
        state40=' '
    if state[4][1] != 0:
        state41=state[4][1]
    else:
        state41=' '
    if state[4][2] != 0:
        state42=state[4][2]
    else:
        state42=' '
    if state[4][3] != 0:
        state43=state[4][3]
    else:
        state43=' '
    if state[4][4] != 0:
        state44=state[4][4]
    else:
        state44=' '
    if state[4][5] != 0:
        state45=state[4][5]
    else:
        state45=' '
    if state[4][6] != 0:
        state46=state[4][6]
    else:
        state46=' '
    if state[4][7] != 0:
        state47=state[4][7]
    else:
        state47=' '
    if state[4][8] != 0:
        state48=state[4][8]
    else:
        state48=' '
        
    if state[5][0] != 0:
        state50=state[5][0]
    else:
        state50=' '
    if state[5][1] != 0:
        state51=state[5][1]
    else:
        state51=' '
    if state[5][2] != 0:
        state52=state[5][2]
    else:
        state52=' '
    if state[5][3] != 0:
        state53=state[5][3]
    else:
        state53=' '
    if state[5][4] != 0:
        state54=state[5][4]
    else:
        state54=' '
    if state[5][5] != 0:
        state55=state[5][5]
    else:
        state55=' '
    if state[5][6] != 0:
        state56=state[5][6]
    else:
        state56=' '
    if state[5][7] != 0:
        state57=state[5][7]
    else:
        state57=' '
    if state[5][8] != 0:
        state58=state[5][8]
    else:
        state58=' '
        
    if state[6][0] != 0:
        state60=state[6][0]
    else:
        state60=' '
    if state[6][1] != 0:
        state61=state[6][1]
    else:
        state61=' '
    if state[6][2] != 0:
        state62=state[6][2]
    else:
        state62=' '
    if state[6][3] != 0:
        state63=state[6][3]
    else:
        state63=' '
    if state[6][4] != 0:
        state64=state[6][4]
    else:
        state64=' '
    if state[6][5] != 0:
        state65=state[6][5]
    else:
        state65=' '
    if state[6][6] != 0:
        state66=state[6][6]
    else:
        state66=' '
    if state[6][7] != 0:
        state67=state[6][7]
    else:
        state67=' '
    if state[6][8] != 0:
        state68=state[6][8]
    else:
        state68=' '
        
    if state[7][0] != 0:
        state70=state[7][0]
    else:
        state70=' '
    if state[7][1] != 0:
        state71=state[7][1]
    else:
        state71=' '
    if state[7][2] != 0:
        state72=state[7][2]
    else:
        state72=' '
    if state[7][3] != 0:
        state73=state[7][3]
    else:
        state73=' '
    if state[7][4] != 0:
        state74=state[7][4]
    else:
        state74=' '
    if state[7][5] != 0:
        state75=state[7][5]
    else:
        state75=' '
    if state[7][6] != 0:
        state76=state[7][6]
    else:
        state76=' '
    if state[7][7] != 0:
        state77=state[7][7]
    else:
        state77=' '
    if state[7][8] != 0:
        state78=state[7][8]
    else:
        state78=' '
        
    if state[8][0] != 0:
        state80=state[8][0]
    else:
        state80=' '
    if state[8][1] != 0:
        state81=state[8][1]
    else:
        state81=' '
    if state[8][2] != 0:
        state82=state[8][2]
    else:
        state82=' '
    if state[8][3] != 0:
        state83=state[8][3]
    else:
        state83=' '
    if state[8][4] != 0:
        state84=state[8][4]
    else:
        state84=' '
    if state[8][5] != 0:
        state85=state[8][5]
    else:
        state85=' '
    if state[8][6] != 0:
        state86=state[8][6]
    else:
        state86=' '
    if state[8][7] != 0:
        state87=state[8][7]
    else:
        state87=' '
    if state[8][8] != 0:
        state88=state[8][8]
    else:
        state88=' '
    print('\n{} {} {} | {} {} {} | {} {} {}\n{} {} {} | {} {} {} | {} {} {}\n{} {} {} | {} {} {} | {} {} {}\n----------------------\n{} {} {} | {} {} {} | {} {} {}\n{} {} {} | {} {} {} | {} {} {}\n{} {} {} | {} {} {} | {} {} {}\n-----------------------\n{} {} {} | {} {} {} | {} {} {}\n{} {} {} | {} {} {} | {} {} {}\n{} {} {} | {} {} {} | {} {} {}\n'.format(state00,state01,state02,state03,state04,state05,state06,state07,state08,state10,state11,state12,state13,state14,state15,state16,state17,state18,state20,state21,state22,state23,state24,state25,state26,state27,state28,state30,state31,state32,state33,state34,state35,state36,state37,state38,state40,state41,state42,state43,state44,state45,state46,state47,state48,state50,state51,state52,state53,state54,state55,state56,state57,state58,state60,state61,state62,state63,state64,state65,state66,state67,state68,state70,state71,state72,state73,state74,state75,state76,state77,state78,state80,state81,state82,state83,state84,state85,state86,state87,state88))
# https://stackoverflow.com/questions/21270501/how-to-create-lists-of-3x3-sudoku-block-in-python
def getBlocks(board):
    answer = []
    for r in range(3):
        for c in range(3):
            block = []
            for i in range(3):
                for j in range(3):
                    block.append(board[3*r + i][3*c + j])
            answer.append(block)
    return answer
def validMoves(state):
    copyState=deepcopy(state)
    validMoves=[]
    
    row0=copyState[0]                  # Row1
    row1=copyState[1]                  # Row2
    row2=copyState[2]                  # Row3
    row3=copyState[3]                  # Row4
    row4=copyState[4]                  # Row5
    row5=copyState[5]                  # Row6
    row6=copyState[6]                  # Row7
    row7=copyState[7]                  # Row8
    row8=copyState[8]                  # Row9
    
    col0=[copyState[0][0],copyState[1][0],copyState[2][0],copyState[3][0],copyState[4][0],copyState[5][0],copyState[6][0],copyState[7][0],copyState[8][0]]
    col1=[copyState[0][1],copyState[1][1],copyState[2][1],copyState[3][1],copyState[4][1],copyState[5][1],copyState[6][1],copyState[7][1],copyState[8][1]]
    col2=[copyState[0][2],copyState[1][2],copyState[2][2],copyState[3][2],copyState[4][2],copyState[5][2],copyState[6][2],copyState[7][2],copyState[8][2]]
    col3=[copyState[0][3],copyState[1][3],copyState[2][3],copyState[3][3],copyState[4][3],copyState[5][3],copyState[6][3],copyState[7][3],copyState[8][3]]
    col4=[copyState[0][4],copyState[1][4],copyState[2][4],copyState[3][4],copyState[4][4],copyState[5][4],copyState[6][4],copyState[7][4],copyState[8][4]]
    col5=[copyState[0][5],copyState[1][5],copyState[2][5],copyState[3][5],copyState[4][5],copyState[5][5],copyState[6][5],copyState[7][5],copyState[8][5]]
    col6=[copyState[0][6],copyState[1][6],copyState[2][6],copyState[3][6],copyState[4][6],copyState[5][6],copyState[6][6],copyState[7][6],copyState[8][6]]
    col7=[copyState[0][7],copyState[1][7],copyState[2][7],copyState[3][7],copyState[4][7],copyState[5][7],copyState[6][7],copyState[7][7],copyState[8][7]]
    col8=[copyState[0][8],copyState[1][8],copyState[2][8],copyState[3][8],copyState[4][8],copyState[5][8],copyState[6][8],copyState[7][8],copyState[8][8]]
    
    #Blocks
    block1 = getBlocks(state)[0]
    block2 = getBlocks(state)[1]
    block3 = getBlocks(state)[2]
    block4 = getBlocks(state)[3]
    block5 = getBlocks(state)[4]
    block6 = getBlocks(state)[5]
    block7 = getBlocks(state)[6]
    block8 = getBlocks(state)[7]
    block9 = getBlocks(state)[8]
    
    index=0
    possible_numbers=[0,1,2,3,4,5,6,7,8,9]
    # Parse through each square column wise and increment the index, 
    #if the square is empty, calculate the potential values 
    #for that square and append the index and value in the list
    for i in row0:
        index+=1
        if i == 0:
            if index==1:
                existingNumbers=block1    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col00=col0+row0
                main_list00 = np.setdiff1d(valid_numbers,row_col00)
                main_list00=main_list00.tolist()
                for x in main_list00:
                    validMoves.append([index,x])
            if index==2:
                existingNumbers=block1    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col01=col1+row0
                main_list01 = np.setdiff1d(valid_numbers,row_col01)
                main_list01=main_list01.tolist()
                for x in main_list01:
                    validMoves.append([index,x])
            if index==3:
                existingNumbers=block1    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col02=col2+row0
                main_list02 = np.setdiff1d(valid_numbers,row_col02)
                main_list02=main_list02.tolist()
                for x in main_list02:
                    validMoves.append([index,x])
              
            if index==4:
                existingNumbers=block2    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col03=col3+row0
                main_list03 = np.setdiff1d(valid_numbers,row_col03)
                main_list03=main_list03.tolist()
                for x in main_list03:
                    validMoves.append([index,x])
            if index==5:
                existingNumbers=block2    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col04=col4+row0
                main_list04 = np.setdiff1d(valid_numbers,row_col04)
                main_list04=main_list04.tolist()
                for x in main_list04:
                    validMoves.append([index,x])
            if index==6:
                existingNumbers=block2    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col05=col5+row0
                main_list05 = np.setdiff1d(valid_numbers,row_col05)
                main_list05=main_list05.tolist()
                for x in main_list05:
                    validMoves.append([index,x])
                    
            if index==7:
                existingNumbers=block3    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col06=col6+row0
                main_list06 = np.setdiff1d(valid_numbers,row_col06)
                main_list06=main_list06.tolist()
                for x in main_list06:
                    validMoves.append([index,x])
            if index==8:
                existingNumbers=block3    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col07=col7+row0
                main_list07 = np.setdiff1d(valid_numbers,row_col07)
                main_list07=main_list07.tolist()
                for x in main_list07:
                    validMoves.append([index,x])
            if index==9:
                existingNumbers=block3    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col08=col8+row0
                main_list08 = np.setdiff1d(valid_numbers,row_col08)
                main_list08=main_list08.tolist()
                for x in main_list08:
                    validMoves.append([index,x])
    
    for i in row1:
        index+=1
        if i == 0:
            if index==10:
                existingNumbers=block1    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col10=col0+row1
                main_list10 = np.setdiff1d(valid_numbers,row_col10)
                main_list10=main_list10.tolist()
                for x in main_list10:
                    validMoves.append([index,x])
            if index==11:
                existingNumbers=block1    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col11=col1+row1
                main_list11 = np.setdiff1d(valid_numbers,row_col11)
                main_list11=main_list11.tolist()
                for x in main_list11:
                    validMoves.append([index,x])
            if index==12:
                existingNumbers=block1    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col12=col2+row1
                main_list12 = np.setdiff1d(valid_numbers,row_col12)
                main_list12=main_list12.tolist()
                for x in main_list12:
                    validMoves.append([index,x])
              
            if index==13:
                existingNumbers=block2    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col13=col3+row1
                main_list13 = np.setdiff1d(valid_numbers,row_col13)
                main_list13=main_list13.tolist()
                for x in main_list13:
                    validMoves.append([index,x])
            if index==14:
                existingNumbers=block2    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col14=col4+row1
                main_list14 = np.setdiff1d(valid_numbers,row_col14)
                main_list14=main_list14.tolist()
                for x in main_list14:
                    validMoves.append([index,x])
            if index==15:
                existingNumbers=block2    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col15=col5+row1
                main_list15 = np.setdiff1d(valid_numbers,row_col15)
                main_list15=main_list15.tolist()
                for x in main_list15:
                    validMoves.append([index,x])
                    
            if index==16:
                existingNumbers=block3    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col16=col6+row1
                main_list16 = np.setdiff1d(valid_numbers,row_col16)
                main_list16=main_list16.tolist()
                for x in main_list16:
                    validMoves.append([index,x])
            if index==17:
                existingNumbers=block3    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col17=col7+row1
                main_list17 = np.setdiff1d(valid_numbers,row_col17)
                main_list17=main_list17.tolist()
                for x in main_list17:
                    validMoves.append([index,x])
            if index==18:
                existingNumbers=block3    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col18=col8+row1
                main_list18 = np.setdiff1d(valid_numbers,row_col18)
                main_list18=main_list18.tolist()
                for x in main_list18:
                    validMoves.append([index,x])
    
    for i in row2:
        index+=1
        if i == 0:
            if index==19:
                existingNumbers=block1    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col20=col0+row2
                main_list20 = np.setdiff1d(valid_numbers,row_col20)
                main_list20=main_list20.tolist()
                for x in main_list20:
                    validMoves.append([index,x])
            if index==20:
                existingNumbers=block1    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col21=col1+row2
                main_list21 = np.setdiff1d(valid_numbers,row_col21)
                main_list21=main_list21.tolist()
                for x in main_list21:
                    validMoves.append([index,x])
            if index==21:
                existingNumbers=block1    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col22=col2+row2
                main_list22 = np.setdiff1d(valid_numbers,row_col22)
                main_list22=main_list22.tolist()
                for x in main_list22:
                    validMoves.append([index,x])
              
            if index==22:
                existingNumbers=block2    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col23=col3+row2
                main_list23 = np.setdiff1d(valid_numbers,row_col23)
                main_list23=main_list23.tolist()
                for x in main_list23:
                    validMoves.append([index,x])
            if index==23:
                existingNumbers=block2    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col24=col4+row2
                main_list24 = np.setdiff1d(valid_numbers,row_col24)
                main_list24=main_list24.tolist()
                for x in main_list24:
                    validMoves.append([index,x])
            if index==24:
                existingNumbers=block2    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col25=col5+row2
                main_list25 = np.setdiff1d(valid_numbers,row_col25)
                main_list25=main_list25.tolist()
                for x in main_list25:
                    validMoves.append([index,x])
                    
            if index==25:
                existingNumbers=block3    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col26=col6+row2
                main_list26 = np.setdiff1d(valid_numbers,row_col26)
                main_list26=main_list26.tolist()
                for x in main_list26:
                    validMoves.append([index,x])
            if index==26:
                existingNumbers=block3    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col27=col7+row2
                main_list27 = np.setdiff1d(valid_numbers,row_col27)
                main_list27=main_list27.tolist()
                for x in main_list27:
                    validMoves.append([index,x])
            if index==27:
                existingNumbers=block3    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col28=col8+row2
                main_list28 = np.setdiff1d(valid_numbers,row_col28)
                main_list28=main_list28.tolist()
                for x in main_list28:
                    validMoves.append([index,x])
        
    #--------------------------------------------------------------------------------------------------------
    for i in row3:
        index+=1
        if i == 0:
            if index==28:
                existingNumbers=block4    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col30=col0+row3
                main_list30 = np.setdiff1d(valid_numbers,row_col30)
                main_list30=main_list30.tolist()
                for x in main_list30:
                    validMoves.append([index,x])
            if index==29:
                existingNumbers=block4    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col31=col1+row3
                main_list31 = np.setdiff1d(valid_numbers,row_col31)
                main_list31=main_list31.tolist()
                for x in main_list31:
                    validMoves.append([index,x])
            if index==30:
                existingNumbers=block4    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col32=col2+row3
                main_list32 = np.setdiff1d(valid_numbers,row_col32)
                main_list32=main_list32.tolist()
                for x in main_list32:
                    validMoves.append([index,x])
              
            if index==31:
                existingNumbers=block5    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col33=col3+row3
                main_list33 = np.setdiff1d(valid_numbers,row_col33)
                main_list33=main_list33.tolist()
                for x in main_list33:
                    validMoves.append([index,x])
            if index==32:
                existingNumbers=block5    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col34=col4+row3
                main_list34 = np.setdiff1d(valid_numbers,row_col34)
                main_list34=main_list34.tolist()
                for x in main_list34:
                    validMoves.append([index,x])
            if index==33:
                existingNumbers=block5    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col35=col5+row3
                main_list35 = np.setdiff1d(valid_numbers,row_col35)
                main_list35=main_list35.tolist()
                for x in main_list35:
                    validMoves.append([index,x])
                    
            if index==34:
                existingNumbers=block6    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col36=col6+row3
                main_list36 = np.setdiff1d(valid_numbers,row_col36)
                main_list36=main_list36.tolist()
                for x in main_list36:
                    validMoves.append([index,x])
            if index==35:
                existingNumbers=block6    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col37=col7+row3
                main_list37 = np.setdiff1d(valid_numbers,row_col37)
                main_list37=main_list37.tolist()
                for x in main_list37:
                    validMoves.append([index,x])
            if index==36:
                existingNumbers=block6    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col38=col8+row3
                main_list38 = np.setdiff1d(valid_numbers,row_col38)
                main_list38=main_list38.tolist()
                for x in main_list38:
                    validMoves.append([index,x])
    
    for i in row4:
        index+=1
        if i == 0:
            if index==37:
                existingNumbers=block4    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col40=col0+row4
                main_list40 = np.setdiff1d(valid_numbers,row_col40)
                main_list40=main_list40.tolist()
                for x in main_list40:
                    validMoves.append([index,x])
            if index==38:
                existingNumbers=block4    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col41=col1+row4
                main_list41 = np.setdiff1d(valid_numbers,row_col41)
                main_list41=main_list41.tolist()
                for x in main_list41:
                    validMoves.append([index,x])
            if index==39:
                existingNumbers=block4    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col42=col2+row4
                main_list42 = np.setdiff1d(valid_numbers,row_col42)
                main_list42=main_list42.tolist()
                for x in main_list42:
                    validMoves.append([index,x])
              
            if index==40:
                existingNumbers=block5    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col43=col3+row4
                main_list43 = np.setdiff1d(valid_numbers,row_col43)
                main_list43=main_list43.tolist()
                for x in main_list43:
                    validMoves.append([index,x])
            if index==41:
                existingNumbers=block5    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col44=col4+row4
                main_list44 = np.setdiff1d(valid_numbers,row_col44)
                main_list44=main_list44.tolist()
                for x in main_list44:
                    validMoves.append([index,x])
            if index==42:
                existingNumbers=block5    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col45=col5+row4
                main_list45 = np.setdiff1d(valid_numbers,row_col45)
                main_list45=main_list45.tolist()
                for x in main_list45:
                    validMoves.append([index,x])
                    
            if index==43:
                existingNumbers=block6    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col46=col6+row4
                main_list46 = np.setdiff1d(valid_numbers,row_col46)
                main_list46=main_list46.tolist()
                for x in main_list46:
                    validMoves.append([index,x])
            if index==44:
                existingNumbers=block6    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col47=col7+row4
                main_list47 = np.setdiff1d(valid_numbers,row_col47)
                main_list47=main_list47.tolist()
                for x in main_list47:
                    validMoves.append([index,x])
            if index==45:
                existingNumbers=block6    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col48=col8+row4
                main_list48 = np.setdiff1d(valid_numbers,row_col48)
                main_list48=main_list48.tolist()
                for x in main_list48:
                    validMoves.append([index,x])
    
    for i in row5:
        index+=1
        if i == 0:
            if index==46:
                existingNumbers=block4    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col50=col0+row5
                main_list50 = np.setdiff1d(valid_numbers,row_col50)
                main_list50=main_list50.tolist()
                for x in main_list50:
                    validMoves.append([index,x])
            if index==47:
                existingNumbers=block4    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col51=col1+row5
                main_list51 = np.setdiff1d(valid_numbers,row_col51)
                main_list51=main_list51.tolist()
                for x in main_list51:
                    validMoves.append([index,x])
            if index==48:
                existingNumbers=block4    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col52=col2+row5
                main_list52 = np.setdiff1d(valid_numbers,row_col52)
                main_list52=main_list52.tolist()
                for x in main_list52:
                    validMoves.append([index,x])
              
            if index==49:
                existingNumbers=block5    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col53=col3+row5
                main_list53 = np.setdiff1d(valid_numbers,row_col53)
                main_list53=main_list53.tolist()
                for x in main_list53:
                    validMoves.append([index,x])
            if index==50:
                existingNumbers=block5    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col54=col4+row5
                main_list54 = np.setdiff1d(valid_numbers,row_col54)
                main_list54=main_list54.tolist()
                for x in main_list54:
                    validMoves.append([index,x])
            if index==51:
                existingNumbers=block5    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col55=col5+row5
                main_list55 = np.setdiff1d(valid_numbers,row_col55)
                main_list55=main_list55.tolist()
                for x in main_list55:
                    validMoves.append([index,x])
                    
            if index==52:
                existingNumbers=block6    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col56=col6+row5
                main_list56 = np.setdiff1d(valid_numbers,row_col56)
                main_list56=main_list56.tolist()
                for x in main_list56:
                    validMoves.append([index,x])
            if index==53:
                existingNumbers=block6    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col57=col7+row5
                main_list57 = np.setdiff1d(valid_numbers,row_col57)
                main_list57=main_list57.tolist()
                for x in main_list57:
                    validMoves.append([index,x])
            if index==54:
                existingNumbers=block6    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col58=col8+row5
                main_list58 = np.setdiff1d(valid_numbers,row_col58)
                main_list58=main_list58.tolist()
                for x in main_list58:
                    validMoves.append([index,x])
    #------------------------------------------------------------------------------------------------
    for i in row6:
        index+=1
        if i == 0:
            if index==55:
                existingNumbers=block7    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col60=col0+row6
                main_list60 = np.setdiff1d(valid_numbers,row_col60)
                main_list60=main_list60.tolist()
                for x in main_list60:
                    validMoves.append([index,x])
            if index==56:
                existingNumbers=block7    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col61=col1+row6
                main_list61 = np.setdiff1d(valid_numbers,row_col61)
                main_list61=main_list61.tolist()
                for x in main_list61:
                    validMoves.append([index,x])
            if index==57:
                existingNumbers=block7    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col62=col2+row6
                main_list62 = np.setdiff1d(valid_numbers,row_col62)
                main_list62=main_list62.tolist()
                for x in main_list62:
                    validMoves.append([index,x])
              
            if index==58:
                existingNumbers=block8    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col63=col3+row6
                main_list63 = np.setdiff1d(valid_numbers,row_col63)
                main_list63=main_list63.tolist()
                for x in main_list63:
                    validMoves.append([index,x])
            if index==59:
                existingNumbers=block8    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col64=col4+row6
                main_list64 = np.setdiff1d(valid_numbers,row_col64)
                main_list64=main_list64.tolist()
                for x in main_list64:
                    validMoves.append([index,x])
            if index==60:
                existingNumbers=block8    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col65=col5+row6
                main_list65 = np.setdiff1d(valid_numbers,row_col65)
                main_list65=main_list65.tolist()
                for x in main_list65:
                    validMoves.append([index,x])
                    
            if index==61:
                existingNumbers=block9    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col66=col6+row6
                main_list66 = np.setdiff1d(valid_numbers,row_col66)
                main_list66=main_list66.tolist()
                for x in main_list66:
                    validMoves.append([index,x])
            if index==62:
                existingNumbers=block9    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col67=col7+row6
                main_list67 = np.setdiff1d(valid_numbers,row_col67)
                main_list67=main_list67.tolist()
                for x in main_list67:
                    validMoves.append([index,x])
            if index==63:
                existingNumbers=block9    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col68=col8+row6
                main_list68 = np.setdiff1d(valid_numbers,row_col68)
                main_list68=main_list68.tolist()
                for x in main_list68:
                    validMoves.append([index,x])
    
    for i in row7:
        index+=1
        if i == 0:
            if index==64:
                existingNumbers=block7    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col70=col0+row7
                main_list70 = np.setdiff1d(valid_numbers,row_col70)
                main_list70=main_list70.tolist()
                for x in main_list70:
                    validMoves.append([index,x])
            if index==65:
                existingNumbers=block7    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col71=col1+row7
                main_list71 = np.setdiff1d(valid_numbers,row_col71)
                main_list71=main_list71.tolist()
                for x in main_list71:
                    validMoves.append([index,x])
            if index==66:
                existingNumbers=block7    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col72=col2+row7
                main_list72 = np.setdiff1d(valid_numbers,row_col72)
                main_list72=main_list72.tolist()
                for x in main_list72:
                    validMoves.append([index,x])
              
            if index==67:
                existingNumbers=block8    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col73=col3+row7
                main_list73 = np.setdiff1d(valid_numbers,row_col73)
                main_list73=main_list73.tolist()
                for x in main_list73:
                    validMoves.append([index,x])
            if index==68:
                existingNumbers=block8    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col74=col4+row7
                main_list74 = np.setdiff1d(valid_numbers,row_col74)
                main_list74=main_list74.tolist()
                for x in main_list74:
                    validMoves.append([index,x])
            if index==69:
                existingNumbers=block8    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col75=col5+row7
                main_list75 = np.setdiff1d(valid_numbers,row_col75)
                main_list75=main_list75.tolist()
                for x in main_list75:
                    validMoves.append([index,x])
                    
            if index==70:
                existingNumbers=block9    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col76=col6+row7
                main_list76 = np.setdiff1d(valid_numbers,row_col76)
                main_list76=main_list76.tolist()
                for x in main_list76:
                    validMoves.append([index,x])
            if index==71:
                existingNumbers=block9    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col77=col7+row7
                main_list77 = np.setdiff1d(valid_numbers,row_col77)
                main_list77=main_list77.tolist()
                for x in main_list77:
                    validMoves.append([index,x])
            if index==72:
                existingNumbers=block9    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col78=col8+row7
                main_list78 = np.setdiff1d(valid_numbers,row_col78)
                main_list78=main_list78.tolist()
                for x in main_list78:
                    validMoves.append([index,x])
    
    for i in row8:
        index+=1
        if i == 0:
            if index==73:
                existingNumbers=block7    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col80=col0+row8
                main_list80 = np.setdiff1d(valid_numbers,row_col80)
                main_list80=main_list80.tolist()
                for x in main_list80:
                    validMoves.append([index,x])
            if index==74:
                existingNumbers=block7    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col81=col1+row8
                main_list81 = np.setdiff1d(valid_numbers,row_col81)
                main_list81=main_list81.tolist()
                for x in main_list81:
                    validMoves.append([index,x])
            if index==75:
                existingNumbers=block7    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col82=col2+row8
                main_list82 = np.setdiff1d(valid_numbers,row_col82)
                main_list82=main_list82.tolist()
                for x in main_list82:
                    validMoves.append([index,x])
              
            if index==76:
                existingNumbers=block8    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col83=col3+row8
                main_list83 = np.setdiff1d(valid_numbers,row_col83)
                main_list83=main_list83.tolist()
                for x in main_list83:
                    validMoves.append([index,x])
            if index==77:
                existingNumbers=block8    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col84=col4+row8
                main_list84 = np.setdiff1d(valid_numbers,row_col84)
                main_list84=main_list84.tolist()
                for x in main_list84:
                    validMoves.append([index,x])
            if index==78:
                existingNumbers=block8    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col85=col5+row8
                main_list85 = np.setdiff1d(valid_numbers,row_col85)
                main_list85=main_list85.tolist()
                for x in main_list85:
                    validMoves.append([index,x])
                    
            if index==79:
                existingNumbers=block9    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col86=col6+row8
                main_list86 = np.setdiff1d(valid_numbers,row_col86)
                main_list86=main_list86.tolist()
                for x in main_list86:
                    validMoves.append([index,x])
            if index==80:
                existingNumbers=block9    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col87=col7+row8
                main_list87 = np.setdiff1d(valid_numbers,row_col87)
                main_list87=main_list87.tolist()
                for x in main_list87:
                    validMoves.append([index,x])
            if index==81:
                existingNumbers=block9    
                valid_number=np.setdiff1d(possible_numbers,existingNumbers)
                valid_numbers=valid_number.tolist()
                row_col88=col8+row8
                main_list88 = np.setdiff1d(valid_numbers,row_col88)
                main_list88=main_list88.tolist()
                for x in main_list88:
                    validMoves.append([index,x])
    
    
    return validMoves
def makeMove(state, move):
    # get the new state by updating the value in its position(index)
    newState=deepcopy(state)
    index=move[0]
    if index==1:
        newState[0][0]=move[1]
    if index==2:
        newState[0][1]=move[1]
    if index==3:
        newState[0][2]=move[1]
    if index==4:
        newState[0][3]=move[1]
    if index==5:
        newState[0][4]=move[1]
    if index==6:
        newState[0][5]=move[1]
    if index==7:
        newState[0][6]=move[1]
    if index==8:
        newState[0][7]=move[1]
    if index==9:
        newState[0][8]=move[1]
    #-------------------------------
    if index==10:
        newState[1][0]=move[1]
    if index==11:
        newState[1][1]=move[1]
    if index==12:
        newState[1][2]=move[1]
    if index==13:
        newState[1][3]=move[1]
    if index==14:
        newState[1][4]=move[1]
    if index==15:
        newState[1][5]=move[1]
    if index==16:
        newState[1][6]=move[1]
    if index==17:
        newState[1][7]=move[1]
    if index==18:
        newState[1][8]=move[1]
    #-------------------------------
    if index==19:
        newState[2][0]=move[1]
    if index==20:
        newState[2][1]=move[1]
    if index==21:
        newState[2][2]=move[1]
    if index==22:
        newState[2][3]=move[1]
    if index==23:
        newState[2][4]=move[1]
    if index==24:
        newState[2][5]=move[1]
    if index==25:
        newState[2][6]=move[1]
    if index==26:
        newState[2][7]=move[1]
    if index==27:
        newState[2][8]=move[1]
    #-------------------------------
    if index==28:
        newState[3][0]=move[1]
    if index==29:
        newState[3][1]=move[1]
    if index==30:
        newState[3][2]=move[1]
    if index==31:
        newState[3][3]=move[1]
    if index==32:
        newState[3][4]=move[1]
    if index==33:
        newState[3][5]=move[1]
    if index==34:
        newState[3][6]=move[1]
    if index==35:
        newState[3][7]=move[1]
    if index==36:
        newState[3][8]=move[1]
    #-------------------------------
    if index==37:
        newState[4][0]=move[1]
    if index==38:
        newState[4][1]=move[1]
    if index==39:
        newState[4][2]=move[1]
    if index==40:
        newState[4][3]=move[1]
    if index==41:
        newState[4][4]=move[1]
    if index==42:
        newState[4][5]=move[1]
    if index==43:
        newState[4][6]=move[1]
    if index==44:
        newState[4][7]=move[1]
    if index==45:
        newState[4][8]=move[1]
    #--------------------------------
    if index==46:
        newState[5][0]=move[1]
    if index==47:
        newState[5][1]=move[1]
    if index==48:
        newState[5][2]=move[1]
    if index==49:
        newState[5][3]=move[1]
    if index==50:
        newState[5][4]=move[1]
    if index==51:
        newState[5][5]=move[1]
    if index==52:
        newState[5][6]=move[1]
    if index==53:
        newState[5][7]=move[1]
    if index==54:
        newState[5][8]=move[1]
    #--------------------------------
    if index==55:
        newState[6][0]=move[1]
    if index==56:
        newState[6][1]=move[1]
    if index==57:
        newState[6][2]=move[1]
    if index==58:
        newState[6][3]=move[1]
    if index==59:
        newState[6][4]=move[1]
    if index==60:
        newState[6][5]=move[1]
    if index==61:
        newState[6][6]=move[1]
    if index==62:
        newState[6][7]=move[1]
    if index==63:
        newState[6][8]=move[1]
    #--------------------------------
    if index==64:
        newState[7][0]=move[1]
    if index==65:
        newState[7][1]=move[1]
    if index==66:
        newState[7][2]=move[1]
    if index==67:
        newState[7][3]=move[1]
    if index==68:
        newState[7][4]=move[1]
    if index==69:
        newState[7][5]=move[1]
    if index==70:
        newState[7][6]=move[1]
    if index==71:
        newState[7][7]=move[1]
    if index==72:
        newState[7][8]=move[1]
    #-------------------------------
    if index==73:
        newState[8][0]=move[1]
    if index==74:
        newState[8][1]=move[1]
    if index==75:
        newState[8][2]=move[1]
    if index==76:
        newState[8][3]=move[1]
    if index==77:
        newState[8][4]=move[1]
    if index==78:
        newState[8][5]=move[1]
    if index==79:
        newState[8][6]=move[1]
    if index==80:
        newState[8][7]=move[1]
    if index==81:
        newState[8][8]=move[1]
    return newState
def stateMoveTuple(state, move):                 # returns tuple of state and move
    stateTuple = tuple(tuple(i) for i in state)
    moveTuple = tuple(move)
    smtuple= (stateTuple,moveTuple)
    return smtuple
import random
def winner(state,move,winnerState):                  # Returns 1 if goal reached
    copy_state= deepcopy(state)
    state_new=makeMove(copy_state,move)
    if state_new==winnerState:
        return 1
    else:
        return 0

def get_winnermoves(state,winnerState):
    # Returns nested list of moves that leads to winner state
    x=0
    index=[]
    ans=[]
    stateFlat = [item for sublist in state for item in sublist]
    winnerStateFlat=[item for sublist in winnerState for item in sublist]
    winner_moves=[]
    for i in stateFlat:
        x+=1
        if i==0:
            index.append(x)
    for i in index:
        ans.append(winnerStateFlat[i-1])
    for i in range(0,len(index)):
        winner_moves.append([index[i],ans[i]])
    return winner_moves

def winnermove(startState,move,winnerState):
    # Returns 1 if the move is the winner move
    winner_moves=get_winnermoves(startState,winnerState)
    if move in winner_moves:
        return 1
    else:
        return 0
    
def getQ(state, Q, move, winnerState,startState):                # Returns Q using key
    if winnermove(startState,move,winnerState):
        return 0
    #print(state,move)
    key= stateMoveTuple(state,move)
    return Q.get(key,1)
    

def epsilonGreedy(epsilon, Q, state,winnerState,startState):    # Returns random move or greedy move based on epsilon value
    #print('state',state)
    valid_moves = validMoves(state)
    #print('valid',valid_moves)
    if valid_moves == []:
        return False
    else:
        if np.random.uniform() < epsilon:
            # Random Move
            return random.choice(valid_moves)
        else:
            # Greedy Move
            Qg = np.array([getQ(state, Q, m, winnerState,startState) for m in valid_moves])
            #print(Qg)
            return valid_moves[ np.argmin(Qg) ]
        
def stateFull(state,move):
    # Checks if there is any empty square
    copy_state= deepcopy(state)
    state_new=makeMove(copy_state,move)
    for i in state_new:
        for element in i:
            if element==0:
                return 0
    return 1
def trainQ(startState,winnerState,nRepetitions, learningRate, epsilonDecayFactor, validMovesF, makeMoveF):
    Q = {}
    #startState=[[1,0,2],[0,5,0],[0,0,6]]
    stepsToGoal = []
    epsilon=1
    goalReached=[]
    for i in range(0,nRepetitions):
        epsilon *= epsilonDecayFactor
        maxMoves=10000
        done= False
        state = startState
        winnerState = winnerState
        path= [startState]
        old_move = None
        old_state = None
        while not done and len(path) < maxMoves:
            move = epsilonGreedy(epsilon, Q, state, winnerState, startState)
            if not move:
                goal=0
                break
            if old_move is not None:
                # update Q
                old_key= stateMoveTuple(old_state,old_move)
                TD_error=1+ getQ(state, Q, move,winnerState, startState) - getQ(old_state, Q, old_move, winnerState, startState)   # Calculate Temporal Difference
                old_Q = getQ (old_state, Q, old_move, winnerState, startState)                      # Get Q from previous state
                old_Q += learningRate * TD_error                           # Update with learning rate and error
                Q[old_key] = old_Q
            old_state= state
            state = makeMoveF(state,move)
            old_move = move
            path.append(state)
            if winner(old_state,old_move,winnerState) or stateFull(old_state,old_move):                                  # Check if Goal reached, then quit 
                done=True
                if winner(old_state,old_move,winnerState):
                    goal=1 
                else:
                    goal=0
        goalReached.append(goal)
        stepsToGoal.append(len(path)-1)
    return Q,np.array(stepsToGoal),goalReached
def testQ(startState,winnerState,Q, maxSteps, validMovesF, makeMoveF):
    epsilon=0
    done= False
    state = startState
    winnerState = winnerState
    path= [startState]
    old_move = None
    old_state = None
    while not done and len(path) < maxSteps:
        move = epsilonGreedy(epsilon, Q, state, winnerState, startState)         # Get greedy move as epsilon is 0
        if not move:
             break
        old_state= state
        state = makeMoveF(state,move)
        old_move = move
        path.append(state)
        if winner(old_state,old_move,winnerState):
            done=True
            print(done)
    return path