# http://www.norvig.com/sudoku.html

def display(result):
    print('\n{} {} {} | {} {} {} | {} {} {}\n{} {} {} | {} {} {} | {} {} {}\n{} {} {} | {} {} {} | {} {} {}\n----------------------\n{} {} {} | {} {} {} | {} {} {}\n{} {} {} | {} {} {} | {} {} {}\n{} {} {} | {} {} {} | {} {} {}\n-----------------------\n{} {} {} | {} {} {} | {} {} {}\n{} {} {} | {} {} {} | {} {} {}\n{} {} {} | {} {} {} | {} {} {}\n'.format(result.get('A1'),result.get('A2'),result.get('A3'),result.get('A4'),result.get('A5'),result.get('A6'),result.get('A7'),result.get('A8'),result.get('A9'),result.get('B1'),result.get('B2'),result.get('B3'),result.get('B4'),result.get('B5'),result.get('B6'),result.get('B7'),result.get('B8'),result.get('B9'),result.get('C1'),result.get('C2'),result.get('C3'),result.get('C4'),result.get('C5'),result.get('C6'),result.get('C7'),result.get('C8'),result.get('C9'),result.get('D1'),result.get('D2'),result.get('D3'),result.get('D4'),result.get('D5'),result.get('D6'),result.get('D7'),result.get('D8'),result.get('D9'),result.get('E1'),result.get('E2'),result.get('E3'),result.get('E4'),result.get('E5'),result.get('E6'),result.get('E7'),result.get('E8'),result.get('E9'),result.get('F1'),result.get('F2'),result.get('F3'),result.get('F4'),result.get('F5'),result.get('F6'),result.get('F7'),result.get('F8'),result.get('F9'),result.get('G1'),result.get('G2'),result.get('G3'),result.get('G4'),result.get('G5'),result.get('G6'),result.get('G7'),result.get('G8'),result.get('G9'),result.get('H1'),result.get('H2'),result.get('H3'),result.get('H4'),result.get('H5'),result.get('H6'),result.get('H7'),result.get('H8'),result.get('H9'),result.get('I1'),result.get('I2'),result.get('I3'),result.get('I4'),result.get('I5'),result.get('I6'),result.get('I7'),result.get('I8'),result.get('I9')))
    
def cross(A, B):
    "Cross product of elements in A and elements in B."
    return [i+j for i in A for j in B]

def get_values(grid):
    """Convert grid to a dict of possible values, {square: digits}, or
    return False if a contradiction is detected."""
    ## To start, every square can be any digit; then assign values from the grid.
    grid_chars=[]
    for d in grid:
        if d in digits or d in '0.':
            grid_chars.append(d)        
    assert len(grid_chars) == 81
    gridValues = dict(zip(squares,grid_chars))
    values = dict((sq, digits) for sq in squares)
    for s,d in gridValues.items():
        if d in digits and not assign(values, s, d):
            return False ## (Fail if we can't assign d to square s.)
    return values

def assign(values, s, d):
    """Eliminate all the other values (except d) from values[s] and propagate.
    Return values, except return False if a contradiction is detected."""
    other_values = values[s].replace(d, '')
    if all(eliminate(values, s, d2) for d2 in other_values):
        return values
    else:
        return False

def eliminate(values, s, d):
    """Eliminate d from values[s]; propagate when values or places <= 2.
    Return values, except return False if a contradiction is detected."""
    if d not in values[s]:
        return values ## Already eliminated
    values[s] = values[s].replace(d,'')
    ## (1) If a square s is reduced to one value d2, then eliminate d2 from the peers.
    if len(values[s]) == 0:
        return False ## Contradiction: removed last value
    elif len(values[s]) == 1:
        d2 = values[s]
        if not all(eliminate(values, s2, d2) for s2 in peers[s]):
            return False
    ## (2) If a unit u is reduced to only one place for a value d, then put it there.
    for unit in units[s]:
        dplaces = [s for s in unit if d in values[s]]
        if len(dplaces) == 0:
            return False ## Contradiction: no place for this value
        elif len(dplaces) == 1:
            # d can only be in one place in unit; assign it there
            place=dplaces[0]
            if not assign(values, place, d):
                return False
    return values

def solve(grid): return dfsearch(get_values(grid))

def dfsearch(values):
    "Using depth-first search and propagation, try all possible values."
    if values is False:
        return False ## Failed earlier
    if all(len(values[sq]) == 1 for sq in squares): 
        return values ## Solved!
    ## Chose the unfilled square s with the fewest possibilities
    totalPossibilities=[]
    for sq in squares:
        if len(values[sq]) > 1:
            totalPossibilities.append((len(values[sq]),sq))
    num,sq=min(totalPossibilities)
    return get_element(dfsearch(assign(values.copy(), sq, d)) 
        for d in values[sq])

def get_element(seq):
    "Return some element of seq that is true."
    for element in seq:
        if element: return element
    return False

#https://towardsdatascience.com/peter-norvigs-sudoku-solver-25779bb349ce

digits   = '123456789'
rows     = 'ABCDEFGHI'
columns     = digits

squares  = cross(rows, columns)
unitlist = ([cross(rows, c) for c in columns] +
            [cross(r, columns) for r in rows] +
            [cross(r, c) for r in ('ABC','DEF','GHI') for c in ('123','456','789')])
units={}
for i in squares:
    for j in unitlist:
        if i in j:
            if i not in units:
                units[i]=[]
            units[i].append(j)
peers = {}
for i in squares:
    unitSet = set()
    for j in units[i]:
        for square in j:
            if square != i:
                unitSet.add(square)
    peers[i] = unitSet