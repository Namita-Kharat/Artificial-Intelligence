import numpy as np
from copy import deepcopy

def printState(state):    
    # Check whether squares are empty or not and assign values accordingly
    if state[0][0] != 0:                          
        state00=state[0][0]
    else:
        state00=' '
    if state[0][1] != 0:
        state01=state[0][1]
    else:
        state01=' '
    if state[0][2] != 0:
        state02=state[0][2]
    else:
        state02=' '
        
    if state[1][0] != 0:
        state10=state[1][0]
    else:
        state10=' '
    if state[1][1] != 0:
        state11=state[1][1]
    else:
        state11=' '
    if state[1][2] != 0:
        state12=state[1][2]
    else:
        state12=' '
        
    if state[2][0] != 0:
        state20=state[2][0]
    else:
        state20=' '
    if state[2][1] != 0:
        state21=state[2][1]
    else:
        state21=' '
    if state[2][2] != 0:
        state22=state[2][2]
    else:
        state22=' '
        
    print('------\n{} {} {}\n{} {} {}\n{} {} {}\n------'.format(state00,state10,state20,state01,state11,state21,state02,state12,state22))
def validMoves(state):
    copyState=deepcopy(state)
    validMoves=[]
    col1=copyState[0]                  # Col1
    col2=copyState[1]                  # Col2
    col3=copyState[2]                  # Col3
    row1=[copyState[0][0],copyState[1][0],copyState[2][0]]
    row2=[copyState[0][1],copyState[1][1],copyState[2][1]]
    row3=[copyState[0][2],copyState[1][2],copyState[2][2]]
    index=0
    existingNumbers=col1+col2+col3    
    possible_numbers=[0,1,2,3,4,5,6,7,8,9]
    valid_number=np.setdiff1d(possible_numbers,existingNumbers)     # Remaining possible numbers
    valid_numbers=valid_number.tolist()
    # Parse through each square column wise and increment the index, 
    #if the square is empty, calculate the potential values 
    #for that square and append the index and value in the list
    for i in col1:
        index+=1
        if i == 0:
            if index==1:
                row_col11=col1+row1
                main_list11 = np.setdiff1d(valid_numbers,row_col11)
                main_list11=main_list11.tolist()
                for x in main_list11:
                    validMoves.append([index,x])
            if index==2:
                row_col12=col1+row2
                main_list12 = np.setdiff1d(valid_numbers,row_col12)
                main_list12=main_list12.tolist()
                for x in main_list12:
                    validMoves.append([index,x])
            if index==3:
                row_col13=col1+row3
                main_list13 = np.setdiff1d(valid_numbers,row_col13)
                main_list13=main_list13.tolist()
                for x in main_list13:
                    validMoves.append([index,x])
#     if 0 in col2:
    for i in col2:
        index+=1
        if i == 0:
            if index==4:
                row_col21=col2+row1
                main_list21 = np.setdiff1d(valid_numbers,row_col21)
                main_list21=main_list21.tolist()
                for x in main_list21:
                    validMoves.append([index,x])
            if index==5:
                row_col22=col2+row2
                main_list22 = np.setdiff1d(valid_numbers,row_col22)
                main_list22=main_list22.tolist()
                for x in main_list22:
                    validMoves.append([index,x])
            if index==6:
                row_col23=col2+row3
                main_list23 = np.setdiff1d(valid_numbers,row_col23)
                main_list23=main_list23.tolist()
                for x in main_list23:
                    validMoves.append([index,x])
#     if 0 in col3:
    for i in col3:
        index+=1
        if i == 0:
            if index==7:
                row_col31=col3+row1
                main_list31 = np.setdiff1d(valid_numbers,row_col31)
                main_list31=main_list31.tolist()
                for x in main_list31:
                    validMoves.append([index,x])
            if index==8:
                row_col32=col3+row2
                main_list32 = np.setdiff1d(valid_numbers,row_col32)
                main_list32=main_list32.tolist()
                for x in main_list32:
                    validMoves.append([index,x])
            if index==9:
                row_col33=col3+row3
                main_list33 = np.setdiff1d(valid_numbers,row_col33)
                main_list33=main_list33.tolist()
                for x in main_list33:
                    validMoves.append([index,x])
    return validMoves
def makeMove(state, move):
    # get the new state by updating the value in its position(index)
    newState=deepcopy(state)
    index=move[0]
    if index==1:
        newState[0][0]=move[1]
    if index==2:
        newState[0][1]=move[1]
    if index==3:
        newState[0][2]=move[1]
    if index==4:
        newState[1][0]=move[1]
    if index==5:
        newState[1][1]=move[1]
    if index==6:
        newState[1][2]=move[1]
    if index==7:
        newState[2][0]=move[1]
    if index==8:
        newState[2][1]=move[1]
    if index==9:
        newState[2][2]=move[1]
    return newState
def stateMoveTuple(state, move):                 # returns tuple of state and move
    stateTuple = tuple(tuple(i) for i in state)
    moveTuple = tuple(move)
    smtuple= (stateTuple,moveTuple)
    return smtuple
import random
def winner(state,move,winnerState):                  # Returns 1 if goal reached
    copy_state= deepcopy(state)
    state_new=makeMove(copy_state,move)
    if state_new==winnerState:
        return 1
    else:
        return 0

def getQ(state, Q, move,winnerState):                # Returns Q using key
    if winner(state,move,winnerState):
        return 0
    key= stateMoveTuple(state,move)
    return Q.get(key,-1)
    

def epsilonGreedy(epsilon, Q, state, winnerState):    # Returns random move or greedy move based on epsilon value
    #print('state',state)
    valid_moves = validMoves(state)
    #print('Valid List',valid_moves)
    if np.random.uniform() < epsilon:
        # Random Move
        return random.choice(valid_moves)
    else:
        # Greedy Move
        Qs = np.array([getQ(state, Q, m,winnerState) for m in valid_moves])
        #print('Q',Qs)
        return valid_moves[ np.argmin(Qs) ]

def stateFull(state,move):
    # Checks if there is any empty square
    copy_state= deepcopy(state)
    state_new=makeMove(copy_state,move)
    for i in state_new:
        for element in i:
            if element==0:
                return 0
    return 1
def trainQ(startState,winningState,nRepetitions, learningRate, epsilonDecayFactor, validMovesF, makeMoveF):
    Q = {}
    #startState=[[1,0,2],[0,5,0],[0,0,6]]
    stepsToGoal = []
    epsilon=1
    
    for i in range(0,nRepetitions):
        epsilon *= epsilonDecayFactor
        maxMoves=10000
        done= False
        state = startState
        winnerState = winningState
        path= [startState]
        old_move = None
        old_state = None
        while not done and len(path) < maxMoves:
            move = epsilonGreedy(epsilon, Q, state, winnerState)
            #print('move',move)
            if old_move is not None:
                # update Q
                old_key= stateMoveTuple(old_state,old_move)
                TD_error=1+ getQ(state, Q, move,winnerState) - getQ(old_state, Q, old_move,winnerState)   # Calculate Temporal Difference
                old_Q = getQ (old_state, Q, old_move,winnerState)                      # Get Q from previous state
                old_Q += learningRate * TD_error                           # Update with learning rate and error
                Q[old_key] = old_Q
            old_state= state
            state = makeMoveF(state,move)
            old_move = move
            path.append(state)
            if winner(old_state,old_move,winnerState):                                  # Check if Goal reached, then quit 
                done=True
                #print('Done',i)
            else:
                if stateFull(old_state,old_move):
                    # if state is full, start again since goal not reached
                    state= startState
        stepsToGoal.append(len(path)-1)
    return Q,np.array(stepsToGoal)
def testQ(startState,winningState,Q, maxSteps, validMovesF, makeMoveF):
    epsilon=0
    done= False
    state = startState
    winnerState = winningState
    path= [startState]
    old_move = None
    old_state = None
    while not done and len(path) < maxSteps:
        move = epsilonGreedy(epsilon, Q, state, winnerState)         # Get greedy move as epsilon is 0
        old_state= state
        state = makeMoveF(state,move)
        old_move = move
        path.append(state)
        if winner(old_state,old_move,winnerState):
            done=True
    return path